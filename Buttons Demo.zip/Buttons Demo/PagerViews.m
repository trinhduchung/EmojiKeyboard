//
//  PagerViews.m
//  iCarouselButtonsDemo
//
//  Created by ThanhDC4 on 11/7/13.
//
//

#import "PagerViews.h"
#define kNumber  5

@implementation PagerViews

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        _scrollView = [[UIScrollView alloc]initWithFrame:CGRectMake(15,100,195,180)];
        _scrollView.delegate = self;
        _scrollView.contentMode = UIViewContentModeScaleAspectFill;
        _scrollView.contentSize = CGSizeMake(1, _scrollView.frame.size.height*kNumber);
        _scrollView.clipsToBounds = YES;
        _scrollView.pagingEnabled = YES;
        _scrollView.showsHorizontalScrollIndicator = NO;
        _scrollView.showsVerticalScrollIndicator = NO;
        _scrollView.scrollsToTop = NO;
        [self addSubview:_scrollView];
        _pageControl = [[UIPageControl alloc]initWithFrame:CGRectMake(15,300, 200, 36)];
        [_pageControl setNumberOfPages:kNumber];
        [_pageControl setCurrentPage:0];
        [self loadScollViewToPage:0];
        [self loadScollViewToPage:1];
        [_pageControl addTarget:self action:@selector(changePage:) forControlEvents:UIControlEventValueChanged];
        [self addSubview:_pageControl];
    }
    return self;
}

-(void)changePage:(id)sender
{
    int page = _pageControl.currentPage;
    [self loadScollViewToPage:page-1];
    [self loadScollViewToPage:page];
    [self loadScollViewToPage:page+1];
    
    CGRect  frame = _scrollView.frame;
    frame.size.height = frame.size.height*page;
    frame.origin.x = 0;
    [_scrollView scrollRectToVisible:frame animated:YES];
    _pageControlUsed = YES;
}

-(void)loadScollViewToPage:(int)page
{
    if(page<0 || page>kNumber-1){
        return;
    }
    PageViewController *vc = [[PageViewController alloc]initWithNibName:@"PageViewController" bundle:nil];
//    UILabel *label =[[UILabel alloc]initWithFrame:CGRectMake(0, 0, _scrollView.frame.size.width, _scrollView.frame.size.height)];
//    label.textAlignment = NSTextAlignmentCenter;
//    label.text = [NSString stringWithFormat:@"%d",page];
//    label.font = [UIFont systemFontOfSize:18];
    //label.backgroundColor = [UIColor orangeColor];
    CGRect frame = _scrollView.frame;
    frame.origin.y = frame.size.height*page;
    vc.view.frame = frame;
    [_scrollView addSubview:vc.view];
}

- (void) scrollViewDidScroll:(UIScrollView *)sender
{
    if (_pageControlUsed)
    {
        return;
    }
    
    // Switch the indicator when more than 50% of the previous/next page is visible
    CGFloat pageHeight = _scrollView.frame.size.height;
    int page = floor( (_scrollView.contentOffset.y - pageHeight / 2) / pageHeight ) + 1;
    _pageControl.currentPage = page;
    
    [self loadScollViewToPage:page - 1];
    [self loadScollViewToPage:page];
    [self loadScollViewToPage:page + 1];
}


// At the begin of scroll dragging, reset the boolean used when scrolls originate from the UIPageControl
- (void) scrollViewWillBeginDragging:(UIScrollView *)scrollView
{
    _pageControlUsed = NO;
}


// At the end of scroll animation, reset the boolean used when scrolls originate from the UIPageControl
- (void) scrollViewDidEndDecelerating:(UIScrollView *)scrollView
{
    _pageControlUsed = NO;
}


/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
