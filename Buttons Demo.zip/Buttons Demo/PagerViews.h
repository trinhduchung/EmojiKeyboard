//
//  PagerViews.h
//  iCarouselButtonsDemo
//
//  Created by ThanhDC4 on 11/7/13.
//
//

#import <UIKit/UIKit.h>
#import "PageViewController.h"

@interface PagerViews : UIView<UIScrollViewDelegate>
@property (strong, nonatomic) UIScrollView *scrollView;
@property (strong, nonatomic) UIPageControl *pageControl;
@property (nonatomic) BOOL pageControlUsed;
@end
